# AP SANTÉ

Plateforme de gestion des écoles de santé au Mali (version 1 — démonstration, données fictives).

## Lancer en local
```
npm install
npm run dev
```

## Déployer sur Vercel
1. Poussez ce projet sur GitHub (compte `apsante-mali`, dépôt `ap-sante`).
2. Sur vercel.com : « Add New Project » → choisissez `ap-sante` → Deploy.
3. Plus tard, ajoutez les variables de `.env.example` dans Vercel > Settings > Environment Variables.

## Contenu
Accueil, tableau de bord, écoles, étudiants, enseignants, classes, notes, paiements (FCFA), bulletins (impression → PDF), contact.
Le dossier `supabase/` contient le schéma de base de données de départ.
