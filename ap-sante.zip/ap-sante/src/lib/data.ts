// Données FICTIVES de démonstration. À remplacer plus tard par Supabase.
export type Section = {
  title: string;
  intro: string;
  cols: [string, string][];
  rows: Record<string, string | number>[];
};

export const fcfa = (n: number) => n.toLocaleString("fr-FR") + " FCFA";

export const sections: Record<string, Section> = {
  ecoles: {
    title: "Écoles",
    intro: "Établissements de santé inscrits sur la plateforme.",
    cols: [["nom", "Nom"], ["ville", "Ville"], ["filieres", "Filières"], ["statut", "Statut"]],
    rows: [
      { nom: "École de Santé Exemple A", ville: "Bamako", filieres: 3, statut: "Actif" },
      { nom: "École de Santé Exemple B", ville: "Sikasso", filieres: 2, statut: "Actif" },
      { nom: "École de Santé Exemple C", ville: "Ségou", filieres: 2, statut: "Essai" },
    ],
  },
  etudiants: {
    title: "Étudiants",
    intro: "Liste des étudiants inscrits (données fictives).",
    cols: [["matricule", "Matricule"], ["nom", "Nom"], ["classe", "Classe"], ["statut", "Statut"]],
    rows: [
      { matricule: "ET-001", nom: "Aminata Diarra", classe: "1ère année Infirmier", statut: "Inscrit" },
      { matricule: "ET-002", nom: "Moussa Traoré", classe: "2e année Sage-femme", statut: "Inscrit" },
      { matricule: "ET-003", nom: "Fatoumata Keïta", classe: "1ère année Infirmier", statut: "Inscrit" },
      { matricule: "ET-004", nom: "Seydou Coulibaly", classe: "3e année Laborantin", statut: "Inscrit" },
    ],
  },
  enseignants: {
    title: "Enseignants",
    intro: "Enseignants et matières (données fictives).",
    cols: [["nom", "Nom"], ["matiere", "Matière"], ["statut", "Statut"]],
    rows: [
      { nom: "Dr Oumar Sidibé", matiere: "Anatomie", statut: "Permanent" },
      { nom: "Mme Kadiatou Sangaré", matiere: "Soins infirmiers", statut: "Permanent" },
      { nom: "Dr Ibrahim Dembélé", matiere: "Gynéco-obstétrique", statut: "Vacataire" },
    ],
  },
  classes: {
    title: "Classes et filières",
    intro: "Organisation pédagogique.",
    cols: [["classe", "Classe"], ["filiere", "Filière"], ["effectif", "Effectif"]],
    rows: [
      { classe: "1ère année Infirmier", filiere: "Soins infirmiers", effectif: 42 },
      { classe: "2e année Sage-femme", filiere: "Maïeutique", effectif: 35 },
      { classe: "3e année Laborantin", filiere: "Biologie médicale", effectif: 28 },
    ],
  },
  notes: {
    title: "Notes",
    intro: "Notes sur 20 (données fictives).",
    cols: [["etudiant", "Étudiant"], ["matiere", "Matière"], ["note", "Note /20"]],
    rows: [
      { etudiant: "Aminata Diarra", matiere: "Anatomie", note: 14.5 },
      { etudiant: "Moussa Traoré", matiere: "Gynéco-obstétrique", note: 16 },
      { etudiant: "Fatoumata Keïta", matiere: "Soins infirmiers", note: 12 },
      { etudiant: "Seydou Coulibaly", matiere: "Biologie", note: 15 },
    ],
  },
  paiements: {
    title: "Paiements",
    intro: "Frais de scolarité en FCFA (données fictives).",
    cols: [["etudiant", "Étudiant"], ["montant", "Montant"], ["reste", "Reste à payer"], ["statut", "Statut"]],
    rows: [
      { etudiant: "Aminata Diarra", montant: fcfa(150000), reste: fcfa(0), statut: "Soldé" },
      { etudiant: "Moussa Traoré", montant: fcfa(100000), reste: fcfa(50000), statut: "Partiel" },
      { etudiant: "Fatoumata Keïta", montant: fcfa(75000), reste: fcfa(75000), statut: "Partiel" },
    ],
  },
  bulletins: {
    title: "Bulletins",
    intro: "Préparation des bulletins. Le bouton ouvre l'impression : choisissez « Enregistrer en PDF ».",
    cols: [["etudiant", "Étudiant"], ["moyenne", "Moyenne /20"], ["mention", "Mention"]],
    rows: [
      { etudiant: "Aminata Diarra", moyenne: 14.5, mention: "Bien" },
      { etudiant: "Moussa Traoré", moyenne: 16, mention: "Très bien" },
      { etudiant: "Fatoumata Keïta", moyenne: 12, mention: "Assez bien" },
    ],
  },
};
