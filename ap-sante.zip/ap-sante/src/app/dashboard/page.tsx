import Link from "next/link";
import { sections } from "@/lib/data";

export default function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-extrabold text-brand">Tableau de bord</h1>
      <p className="mt-1 text-sm">Version de démonstration — données fictives.</p>
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {Object.entries(sections).map(([k, s]) => (
          <Link key={k} href={`/dashboard/${k}`} className="rounded-xl border p-4 shadow-sm hover:border-turq">
            <div className="text-3xl font-extrabold text-turq">{s.rows.length}</div>
            <div className="text-sm font-semibold text-brand">{s.title}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
