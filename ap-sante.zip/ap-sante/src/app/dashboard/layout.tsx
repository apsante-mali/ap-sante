import Link from "next/link";
import Header from "@/components/Header";
import { sections } from "@/lib/data";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Header />
      <div className="mx-auto max-w-5xl px-4 py-6 md:flex md:gap-6">
        <nav className="no-print mb-4 flex gap-2 overflow-x-auto pb-2 md:mb-0 md:w-48 md:flex-col md:overflow-visible">
          <Link href="/dashboard" className="whitespace-nowrap rounded-lg bg-brand px-3 py-2 text-sm font-semibold text-white">Accueil</Link>
          {Object.entries(sections).map(([k, s]) => (
            <Link key={k} href={`/dashboard/${k}`}
              className="whitespace-nowrap rounded-lg bg-brand-light px-3 py-2 text-sm font-semibold text-brand hover:bg-turq-light">
              {s.title}
            </Link>
          ))}
        </nav>
        <section className="min-w-0 flex-1">{children}</section>
      </div>
    </>
  );
}
