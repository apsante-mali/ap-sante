import { notFound } from "next/navigation";
import { sections } from "@/lib/data";
import PrintButton from "@/components/PrintButton";

export function generateStaticParams() {
  return Object.keys(sections).map((section) => ({ section }));
}

export default function SectionPage({ params }: { params: { section: string } }) {
  const s = sections[params.section];
  if (!s) notFound();
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-extrabold text-brand">{s.title}</h1>
        {params.section === "bulletins" && <PrintButton />}
      </div>
      <p className="mt-1 text-sm">{s.intro}</p>
      <div className="mt-4 overflow-x-auto rounded-xl border">
        <table className="w-full text-left text-sm">
          <thead className="bg-brand text-white">
            <tr>{s.cols.map(([k, l]) => <th key={k} className="px-3 py-2">{l}</th>)}</tr>
          </thead>
          <tbody>
            {s.rows.map((r, i) => (
              <tr key={i} className="border-t even:bg-brand-light/40">
                {s.cols.map(([k]) => <td key={k} className="whitespace-nowrap px-3 py-2">{r[k]}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
