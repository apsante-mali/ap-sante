import Header from "@/components/Header";
export default function Contact() {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-xl px-4 py-12">
        <h1 className="text-3xl font-extrabold text-brand">Contact</h1>
        <p className="mt-2">Une question sur AP SANTÉ ? Appelez-nous :</p>
        <div className="mt-6 space-y-3">
          {["92948849", "64298358"].map((n) => (
            <a key={n} href={`tel:+223${n}`}
              className="block rounded-xl bg-turq-light p-4 text-xl font-bold text-brand">📞 {n}</a>
          ))}
        </div>
      </main>
    </>
  );
}
