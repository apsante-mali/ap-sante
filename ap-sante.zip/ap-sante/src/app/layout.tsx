import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AP SANTÉ — Gestion des écoles de santé au Mali",
  description: "Plateforme SaaS de gestion des écoles de santé au Mali.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
