import Link from "next/link";
import Header from "@/components/Header";

const features = [
  ["🏫", "Écoles", "Gérez plusieurs établissements de santé."],
  ["🎓", "Étudiants", "Inscriptions, classes et filières."],
  ["📝", "Notes et bulletins", "Saisie des notes et bulletins PDF."],
  ["💰", "Paiements en FCFA", "Suivi des frais de scolarité."],
];

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <section className="bg-gradient-to-br from-brand to-turq px-4 py-16 text-center text-white">
          <h1 className="mx-auto max-w-2xl text-3xl font-extrabold sm:text-5xl">
            Gérez votre école de santé simplement
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-lg text-white/90">
            AP SANTÉ : la plateforme de gestion des écoles de santé au Mali.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link href="/dashboard" className="rounded-lg bg-white px-6 py-3 font-bold text-brand">Voir la démo</Link>
            <Link href="/contact" className="rounded-lg border border-white px-6 py-3 font-bold">Nous contacter</Link>
          </div>
        </section>
        <section className="mx-auto grid max-w-5xl gap-4 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
          {features.map(([icon, t, d]) => (
            <div key={t} className="rounded-xl border bg-white p-5 shadow-sm">
              <div className="text-3xl">{icon}</div>
              <h3 className="mt-2 font-bold text-brand">{t}</h3>
              <p className="mt-1 text-sm">{d}</p>
            </div>
          ))}
        </section>
      </main>
      <footer className="bg-brand px-4 py-6 text-center text-sm text-white">
        © AP SANTÉ — Contact : 92948849 / 64298358
      </footer>
    </>
  );
}
