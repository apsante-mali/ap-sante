import Link from "next/link";
export default function Header() {
  return (
    <header className="no-print sticky top-0 z-10 border-b bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
        <Link href="/" className="text-xl font-extrabold text-brand">AP <span className="text-turq">SANTÉ</span></Link>
        <nav className="flex gap-4 text-sm font-medium">
          <Link href="/dashboard" className="hover:text-turq">Tableau de bord</Link>
          <Link href="/contact" className="hover:text-turq">Contact</Link>
        </nav>
      </div>
    </header>
  );
}
