"use client";
export default function PrintButton() {
  return (
    <button onClick={() => window.print()}
      className="no-print rounded-lg bg-turq px-4 py-2 font-semibold text-white hover:bg-turq-dark">
      Imprimer / Enregistrer en PDF
    </button>
  );
}
