-- Schéma de départ (à exécuter dans Supabase > SQL Editor, plus tard).
create table ecoles (
  id uuid primary key default gen_random_uuid(),
  nom text not null, ville text, created_at timestamptz default now()
);
create table classes (
  id uuid primary key default gen_random_uuid(),
  ecole_id uuid references ecoles(id) on delete cascade,
  nom text not null, filiere text
);
create table etudiants (
  id uuid primary key default gen_random_uuid(),
  ecole_id uuid references ecoles(id) on delete cascade,
  classe_id uuid references classes(id),
  matricule text, nom text not null
);
create table enseignants (
  id uuid primary key default gen_random_uuid(),
  ecole_id uuid references ecoles(id) on delete cascade,
  nom text not null, matiere text
);
create table notes (
  id uuid primary key default gen_random_uuid(),
  etudiant_id uuid references etudiants(id) on delete cascade,
  matiere text not null, note numeric(4,2) check (note between 0 and 20)
);
create table paiements (
  id uuid primary key default gen_random_uuid(),
  etudiant_id uuid references etudiants(id) on delete cascade,
  montant_fcfa integer not null, date_paiement date default current_date
);
alter table ecoles enable row level security;
alter table classes enable row level security;
alter table etudiants enable row level security;
alter table enseignants enable row level security;
alter table notes enable row level security;
alter table paiements enable row level security;
-- Les règles de sécurité (policies) seront ajoutées à la phase « Authentification ».
