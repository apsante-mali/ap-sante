import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { DEFAULT: "#1F4E79", light: "#DCE6F1", dark: "#153756" },
        turq: { DEFAULT: "#14B8A6", dark: "#0F8F81", light: "#D5F5F1" },
      },
    },
  },
  plugins: [],
};
export default config;
